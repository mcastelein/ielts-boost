# Band 3 — Task 2

**Prompt:** Some people say that the Internet is making the world smaller by bringing people together. To what extent do you agree or disagree?

---

Internet is very important today. Many people use internet every day. I also use internet.

I agree internet make world smaller. Because we can talk to people in other country. For example I can chat my friend in other country use WhatsApp. Before internet we can not do this. So internet is good.

Also internet have many information. We can search anything we want. Student can study use internet. This is very helpful.

But sometime internet is bad. Some people use too much internet and they dont go outside. Also there is bad people on internet. We must be careful.

I think internet is good thing but we should use carefully. Internet make world small yes I agree.

**Word count:** 118
