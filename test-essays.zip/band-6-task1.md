# Band 6 — Task 1

**Prompt:** The table below shows the percentage of household income spent on different categories in five countries. Summarise the information by selecting and reporting the main features and make comparisons where relevant.

---

The table presents data on the proportion of household income allocated to various spending categories across five countries: the UK, France, Germany, Japan, and the USA.

Overall, it is clear that housing represents the largest expenditure for most countries, while clothing accounts for the smallest share in nearly all cases.

In terms of housing, the UK and Japan spend the highest proportion at around 30 percent each, whereas Germany spends the least at approximately 22 percent. France and the USA fall somewhere in between, spending roughly 25 and 27 percent respectively.

Regarding food, it is noticeable that France allocates the highest percentage of income to this category at about 25 percent, which is significantly more than the USA, which spends only 15 percent. The other three countries spend between 18 and 22 percent on food.

When it comes to transport, the USA stands out with the highest expenditure at around 18 percent, likely due to its car-dependent culture. Japan and Germany spend similar amounts of approximately 12 percent, while France and the UK are close behind at 10 and 14 percent.

Finally, clothing represents a relatively minor expense across all five nations, ranging from about 4 percent in Japan to 8 percent in France.

In summary, housing dominates household spending across all countries, but there is notable variation in food and transport expenditure depending on the nation.

**Word count:** 218
