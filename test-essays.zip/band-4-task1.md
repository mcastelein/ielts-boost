# Band 4 — Task 1

**Prompt:** The bar chart below shows the number of visitors to three London museums between 2007 and 2012. Summarise the information by selecting and reporting the main features.

---

The bar chart show how many people visit three museum in London from 2007 to 2012.

First museum is British Museum. It have most visitor every year. In 2007 it have about 5 million visitor and in 2012 it go up to about 5.5 million. So it is increasing.

Second museum is National Gallery. It also have many visitor but less than British Museum. In 2007 it have about 4 million and it stay almost same until 2012. Maybe little bit go up.

Third museum is Science Museum. It have least visitor. In 2007 about 2.5 million people visit and in 2012 it is about 3 million. So it also increasing but still least popular.

Overall all three museum have more visitor in 2012 than 2007. British Museum is most popular always.

**Word count:** 140
