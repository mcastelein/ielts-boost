# Band 5 — Task 2

**Prompt:** Some people think that children should begin their formal education at a very early age. Others think they should begin after 7 years old. Discuss both views and give your opinion.

---

Nowadays many people have different opinion about when children should start school. Some think early is better but others think children should wait until they are 7. I will discuss both side.

First, some people believe children should go to school early because they can learn many things when they are young. For example they can learn reading and writing and also how to be with other children. If they start early they will have more knowledge when they grow up. My cousin started school at age 4 and now she is very smart student.

On the other hand, some people think 7 is better age to start. They say young children need to play and be free. If they go to school too early maybe they will feel stress and not happy. Also some children are not ready for school when they are very young because every child is different.

I think both views have good points. In my opinion the best age is about 5 or 6 because children are not too young but also not too old. They can start learning basic things but still have time to play.

Also I think it depends on the country and culture. In my country most children start at age 6 and I think this is good system.

In conclusion, starting school early has advantages but we should also think about children happiness. I believe around 5 or 6 is the best age to start formal education.

**Word count:** 230
